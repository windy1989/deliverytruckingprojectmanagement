import { ChartDataset } from '../../../index.esm';

const dataset: ChartDataset = {
  data: [],
  fill: true,
};
